class Armor(object):
    """description of class"""
    def __init__(self, brand='', name='', price='', description='', ev=0):
        self.__attributes={}
        self.__attributes['brand']=brand
        self.__attributes['name']=name
        self.__attributes['price']=price
        self.__attributes['description']=description
        self.__attributes['ev']=ev

    def add_attribute(self,attribute, value):
        self.__attributes[attribute] = value

