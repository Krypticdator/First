from GUI_factory import Category_UI
class GUI_armor(Category_UI):
    """description of class"""
    def __init__(self, master, controller = 'none', frametext = 'Armor', first_header = 'Categories', second_header = 'Available', third_header = 'Description'):
        super().__init__(master, controller, frametext, first_header, second_header, third_header)





