class inheritable(object):
    """description of class"""

    def get_num(self):
        return self.num
    def __init__(self, num):
        self.x=0
        self.num = num

