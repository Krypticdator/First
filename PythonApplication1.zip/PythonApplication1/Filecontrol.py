class Filecontrol(object):
    """description of class"""
    def __init__(self):
        self.segmented_file_array = []
    def read_file(self, filepath ,target):
        f = open(filepath, 'r')
        for line in f:
           merkkijono = line.strip()
           target.append(merkkijono)
        f.close()

    def read_file_to_segments(self, filepath, separator):
        f = open(filepath, 'r')
        for line in f:
            merkkijono = line[:-1]
            rivitiedot = merkkijono.split(separator, -1)
            self.segmented_file_array.append(rivitiedot)
        f.close()

