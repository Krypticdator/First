from inheritable import inheritable

class inherited(inheritable):
    """description of class"""


