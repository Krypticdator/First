class Asset(object):
    """description of class"""
    def __init__(self):
        self.__attributes = {}
        self.__jobs = {}


